import {test, expect} from "@playwright/test"

test('Interview practice', async ({page})=>{
    await page.goto('https://testautomationpractice.blogspot.com/')
    await page.getByText('Data Entry Form')
    const nameLabel = await page.getByLabel('Name:')
    await expect(nameLabel).toBeVisible()
    await page.getByPlaceholder('Enter Name').fill('Tamizh')

})